from django.shortcuts import render,HttpResponseRedirect
from django.contrib import auth
from django.contrib.auth import authenticate
from django.contrib.auth.models import User

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
# Create your views here.

def register(request):
    
        form = UserCreationForm(request.POST or None)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/')
    
        form = UserCreationForm()
        context={
        'form' : form
        }
        return render(request,'registration/r1.html',context)



def login_view(request):
    username = request.POST.get('username','')
    m = User.objects.get(username=username)
    password = request.POST.get('password','')
    user =auth.authenticate(username=username,password=password)
    if user is not None and user.is_active:
        auth.login(request,user)
        request.session['member_id'] = m.id
        print("hi request.session['username']")
        return HttpResponseRedirect("/account/loggedin/")
    else:
        return HttpResponseRedirect("/account/invalid/")


def logout(request):
    auth.logout(request)
    del request.session['username']
    return HttpResponseRedirect("/account/loggout/")


